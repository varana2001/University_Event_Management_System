using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace DMDD_Project.Pages.User
{
    public class Delete : PageModel
    {


        public void OnGet()
        {
        }

        public void OnPost(int UserID)
        {
            deleteUser(UserID);
            Response.Redirect("/User/Index");
        }

        private void deleteUser(int UserID){
            try
            {
                string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";

                using (SqlConnection connection = new SqlConnection(connectionString)){
                    connection.Open();

                    string sql = "DELETE FROM [User] WHERE UserID = @UserID";
                    using (SqlCommand command= new SqlCommand(sql, connection)){
                        command.Parameters.AddWithValue("@UserID", UserID);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Cannot delete user" + ex.Message);
            }
        }
    }
}
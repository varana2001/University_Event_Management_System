using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;


namespace DMDD_Project.Pages.User
{
    public class Index : PageModel
    {
        public List<UserInfo> UserList {get; set;} = [];
        public void OnGet()
        {
            try
            {
                string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";

                using (SqlConnection connection = new SqlConnection(connectionString)){
                    connection.Open();

                    string sql = "SELECT * FROM [User]";
                    using (SqlCommand command = new SqlCommand(sql, connection)){
                        using (SqlDataReader reader = command.ExecuteReader()){
                            while(reader.Read()){
                                UserInfo userInfo = new UserInfo();
                                userInfo.UserID = reader.GetInt32(0);
                                userInfo.UserFName = reader.GetString(1);
                                userInfo.UserLName = reader.GetString(2);
                                userInfo.UserEmail = reader.GetString(3);
                                userInfo.UserPhone = reader.GetString(4);
                                userInfo.UserRole = reader.GetString(5);

                                UserList.Add(userInfo);
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("We have an error: " + ex.Message);
            }
        }
    }

    public class UserInfo{

        public int UserID{get; set;}
        public string UserFName {get; set;} = " ";
        public string UserLName {get; set;} = " ";
        public string UserEmail {get; set;} = " ";
        public string UserPhone {get; set;} = " ";
        public string UserRole {get; set;} = " ";

    }
}

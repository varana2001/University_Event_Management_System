using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace DMDD_Project.Pages
{
    public class Create : PageModel
    {
        
        [BindProperty, Required(ErrorMessage = "The FirstName is required")]
        public string UserFName {get; set;} = " ";
        
        [BindProperty, Required(ErrorMessage = "The LastName is required")]
        public string UserLName {get; set;} = " ";
        
        [BindProperty, Required(ErrorMessage = "The Email is required"), EmailAddress]
        public string UserEmail {get; set;} = " ";
        
        [BindProperty, Required (ErrorMessage = "The PhoneNumber is required"), Phone]
        public string UserPhone {get; set;} = " ";
        
        [BindProperty, Required(ErrorMessage = "The Role is required")]
        public string UserRole {get; set;} = " ";

        [BindProperty, Required(ErrorMessage = "The Password is required")]
        public string Password {get; set;} = " ";

        public void OnGet()
        {
        }

        public string ErrorMessage {get; set;} = " ";

        public void OnPost()
        {
            if (!ModelState.IsValid){
                return;
            }

            try
            {
                string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";


                using (SqlConnection connection = new SqlConnection(connectionString)){
                    connection.Open();


                    string sql = "INSERT INTO [User]" + "(UserFName, UserLName, UserEmail, UserPhone, UserRole, Password) VALUES" + "(@UserFName, @UserLName, @UserEmail, @UserPhone, @UserRole, @Password);";

                    using (SqlCommand command = new SqlCommand(sql, connection)){
                        command.Parameters.AddWithValue("@UserFName", UserFName);
                        command.Parameters.AddWithValue("@UserLName", UserLName);
                        command.Parameters.AddWithValue("@UserEmail", UserEmail);
                        command.Parameters.AddWithValue("@UserPhone", UserPhone);
                        command.Parameters.AddWithValue("@UserRole", UserRole);
                        command.Parameters.AddWithValue("@Password", Password);
                        command.ExecuteNonQuery();
                    }

                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                return;
            }

            Response.Redirect("/User/Index");
        }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace University_Event_Management_System.Pages.Events
{
    public class Index : PageModel
    {
        private readonly ILogger<Index> _logger;

        public List<EventInfo> EventsList { get; set; } = new List<EventInfo>();

        public Index(ILogger<Index> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            try
            {
                string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string sql = @"
                        SELECT 
                            [EventID],
                            [VenueID],
                            [EventCategoryID],
                            [OrganizerID],
                            [EventTitle],
                            [EventDescription],
                            [StartDate],
                            [EndDate],
                            [EventBudget],
                            [EventDuration]
                        FROM 
                            [dbo].[Event]";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                EventInfo eventInfo = new EventInfo
                                {
                                    EventID = reader.GetInt32(0),
                                    VenueID = reader.GetInt32(1), // Matches DB type
                                    EventCategoryID = reader.GetInt32(2), // Matches DB type
                                    OrganizerID = reader.GetInt32(3), // Matches DB type
                                    EventTitle = reader.GetString(4),
                                    EventDescription = reader.IsDBNull(5) ? "" : reader.GetString(5), // Handle NULL values in EventDescription

                                    EventBudget = reader.GetDecimal(8).ToString("F2"), // Decimal formatted to two decimal places

                                };

                                EventsList.Add(eventInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Error fetching events: {Message}", ex.Message);
            }
        }
    }

    public class EventInfo
    {
        public int EventID { get; set; }
        public int VenueID { get; set; }  // Ensure these match with your DB types
        public int EventCategoryID { get; set; }
        public int OrganizerID { get; set; }
        public string EventTitle { get; set; } = "";
        public string EventDescription { get; set; } = "";

        public string EventBudget { get; set; } = "";

    }
}

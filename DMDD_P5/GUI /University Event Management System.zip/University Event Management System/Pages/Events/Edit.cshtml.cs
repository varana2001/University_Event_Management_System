using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace University_Event_Management_System.Pages.Events
{
    public class Edit : PageModel
    {
        // Event related properties
        [BindProperty]
        public int EventID { get; set; } // This should not be bindable, it will only be set during retrieval.

        [BindProperty, Required(ErrorMessage = "VenueID is required")]
        public int VenueID { get; set; }

        [BindProperty, Required(ErrorMessage = "EventCategoryID is required")]
        public int EventCategoryID { get; set; }

        [BindProperty, Required(ErrorMessage = "OrganizerID is required")]
        public int OrganizerID { get; set; }

        [BindProperty, Required(ErrorMessage = "Event title is required")]
        public string EventTitle { get; set; } = "";

        [BindProperty, Required(ErrorMessage = "Event description is required")]
        public string EventDescription { get; set; } = "";

        [BindProperty, Required(ErrorMessage = "Start date is required")]
        public DateTime StartDate { get; set; }

        [BindProperty, Required(ErrorMessage = "End date is required")]
        public DateTime EndDate { get; set; }

        [BindProperty, Required(ErrorMessage = "Event budget is required")]
        public decimal EventBudget { get; set; }

        public string ErrorMessage { get; set; } = "";

        // This method runs when the Edit page is accessed, using the EventID from the URL.
        public void OnGet(int id)
        {
            try
            {
                string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Retrieve event data based on the ID
                    string sql = "SELECT * FROM [Event] WHERE EventID = @id";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Assign EventID and other properties from the database
                                EventID = reader.GetInt32(0); 
                                VenueID = reader.GetInt32(1);
                                EventCategoryID = reader.GetInt32(2);
                                OrganizerID = reader.GetInt32(3);
                                EventTitle = reader.GetString(4);
                                EventDescription = reader.IsDBNull(5) ? "" : reader.GetString(5);
                                StartDate = reader.GetDateTime(6);
                                EndDate = reader.GetDateTime(7);
                                EventBudget = reader.GetDecimal(8);
                            }
                            else
                            {
                                // If no event found, show an error message
                                ErrorMessage = "Event not found.";
                                // Optionally, redirect to the event list page
                                Response.Redirect("/Events/Index");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = "An error occurred while retrieving the event: " + ex.Message;
            }
        }

        // This method handles the form submission to update the event
        public void OnPost()
{
    if (!ModelState.IsValid)
    {
        return; // If validation fails, return to the page with validation messages
    }

    try
    {
        string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            // Update the event data in the database
            string sql = @"
                UPDATE [Event] 
                SET 
                    VenueID = @venueid, 
                    EventCategoryID = @eventcategoryid, 
                    OrganizerID = @organizerid, 
                    EventTitle = @eventtitle, 
                    EventDescription = @eventdescription, 
                    StartDate = @startdate, 
                    EndDate = @enddate, 
                    EventBudget = @eventbudget
                WHERE 
                    EventID = @id";

            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                // Add parameters from the form
                command.Parameters.AddWithValue("@venueid", VenueID);
                command.Parameters.AddWithValue("@eventcategoryid", EventCategoryID);
                command.Parameters.AddWithValue("@organizerid", OrganizerID);
                command.Parameters.AddWithValue("@eventtitle", EventTitle);
                command.Parameters.AddWithValue("@eventdescription", EventDescription);
                command.Parameters.AddWithValue("@startdate", StartDate);
                command.Parameters.AddWithValue("@enddate", EndDate);
                command.Parameters.AddWithValue("@eventbudget", EventBudget);
                command.Parameters.AddWithValue("@id", EventID); // Use EventID for the update query

                // Execute the update query
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    ErrorMessage = "Failed to update the event. Please try again.";
                }
            }
        }

        // After successful update, redirect back to the events list page
        Response.Redirect("/Events/Index");
    }
    catch (Exception ex)
    {
        ErrorMessage = "An error occurred while updating the event: " + ex.Message;
    }
}

    }
}

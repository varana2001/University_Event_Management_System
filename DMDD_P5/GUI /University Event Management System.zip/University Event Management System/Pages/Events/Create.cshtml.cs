using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace UEMS.Pages.Events
{
    public class Create : PageModel
    {
        // Event related properties
        [BindProperty, Required(ErrorMessage = "VenueID is required")]
        public int VenueID { get; set; }

        [BindProperty, Required(ErrorMessage = "EventCategoryID is required")]
        public int EventCategoryID { get; set; }

        [BindProperty, Required(ErrorMessage = "OrganizerID is required")]
        public int OrganizerID { get; set; }

        [BindProperty, Required(ErrorMessage = "Event title is required")]
        public string EventTitle { get; set; } = "";

        [BindProperty, Required(ErrorMessage = "Event description is required")]
        public string EventDescription { get; set; } = "";

        [BindProperty, Required(ErrorMessage = "Start date is required")]
        public DateTime StartDate { get; set; }

        [BindProperty, Required(ErrorMessage = "End date is required")]
        public DateTime EndDate { get; set; }

        [BindProperty, Required(ErrorMessage = "Event budget is required")]
        public decimal EventBudget { get; set; }

        public string ErrorMessage { get; set; } = "";

        public void OnGet()
        {
        }

        public void OnPost()
        {
            if (!ModelState.IsValid)
            {
                return;
            }

            try
            {
                // Connection string
                string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Insert event data
                    string sqlEvent = @"
                        INSERT INTO [dbo].[Event]
                            ([VenueID], [EventCategoryID], [OrganizerID], [EventTitle], [EventDescription], [StartDate], [EndDate], [EventBudget])
                        VALUES
                            (@venueid, @eventcategoryid, @organizerid, @eventtitle, @eventdescription, @startdate, @enddate, @eventbudget);";

                    using (SqlCommand commandEvent = new SqlCommand(sqlEvent, connection))
                    {
                        commandEvent.Parameters.AddWithValue("@venueid", VenueID);
                        commandEvent.Parameters.AddWithValue("@eventcategoryid", EventCategoryID);
                        commandEvent.Parameters.AddWithValue("@organizerid", OrganizerID);
                        commandEvent.Parameters.AddWithValue("@eventtitle", EventTitle);
                        commandEvent.Parameters.AddWithValue("@eventdescription", EventDescription);
                        commandEvent.Parameters.AddWithValue("@startdate", StartDate);
                        commandEvent.Parameters.AddWithValue("@enddate", EndDate);
                        commandEvent.Parameters.AddWithValue("@eventbudget", EventBudget);
                        commandEvent.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                return;
            }

            Response.Redirect("/Events/Index");
        }
    }
}

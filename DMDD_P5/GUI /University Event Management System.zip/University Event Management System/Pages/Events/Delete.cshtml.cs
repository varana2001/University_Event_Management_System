using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace University_Event_Management_System.Pages.Events
{
    public class Delete(ILogger<Delete> logger) : PageModel
    {
        private readonly ILogger<Delete> _logger = logger;

        // Bind EventID and EventTitle to be available in the view
        [BindProperty]
        public int EventID { get; set; }

        [BindProperty]
        public required string EventTitle { get; set; }

        // Load the event details for confirmation
        public void OnGet(int EventID)
        {
            try
            {
                string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";
                
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Get event details to show in the confirmation
                    string sql = "SELECT EventTitle FROM [Event] WHERE EventID = @EventID";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@EventID", EventID);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                EventTitle = reader.GetString(0);
                                this.EventID = EventID;
                            }
                            else
                            {
                                // Event not found, redirect or show error
                                _logger.LogWarning("Event not found.");
                                RedirectToPage("/Events/Index");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error loading event: {ex.Message}");
                ModelState.AddModelError(string.Empty, "Error loading event.");
            }
        }

        // Handle form submission to delete event
        public IActionResult OnPost()
        {
            try
            {
                DeleteEvent(EventID);
                return RedirectToPage("/Events/Index");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error deleting event with ID {EventID}: {ex.Message}");
                ModelState.AddModelError(string.Empty, "Error deleting event.");
                return Page(); // Stay on the same page to show the error
            }
        }

        private void DeleteEvent(int EventID)
        {
            string connectionString = "Server= localhost; Database= UniversityEventManagementSystem; User Id = SA; Password = AtharvaNEU7@; TrustServerCertificate= True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sql = "DELETE FROM [Event] WHERE EventID = @EventID";

                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@EventID", EventID);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace University_Event_Management_System.Pages
{
    public class LoginModel : PageModel
{
    [BindProperty]
    public LoginInputModel Input { get; set; } = new LoginInputModel();

    // Removed 'required' from ErrorMessage to allow null values
    public string? ErrorMessage { get; set; }

    public void OnGet()
    {
        // Clear any existing messages
        ErrorMessage = null;
    }

    public IActionResult OnPost()
    {
        // Simple authentication logic for demo (replace with actual database logic)
        if (Input.Username == "admin" && Input.Password == "password123")
        {
            // Redirect to Users page on successful login
            return RedirectToPage("/Users");
        }
        else
        {
            // Show error message
            ErrorMessage = "Invalid username or password!";
            return Page();
        }
    }

    public class LoginInputModel
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}

}
